		Greetings to you 
 	Master your computer management!

This program includes:

1. Enabling the Command Line
2. Turning on the browser
3. Enabling web browser Telegram
4. Enabling the Web browser Discord 
5. Opening the Task Manager
6. Opening the Device Manager
7. Emergency shutdown of the computer
8. Starting the process explorer.exe , if one is blocked or not running.

9.Information about the program

In the future, there will be updates to this program, improved functionality and appearance.

Important! The program is divided into 2 types Standard and Pro 

Standart is used to control the computer, and Pro is used to fix errors or critical situations.