from time import sleep
import os
from tkinter import *
from tkinter import ttk
import webbrowser

def click_info ():
    root_info.destroy()

def info():
    global root_info
    root_info = Tk()
    root_info.geometry("400x200")
    root_info.title("Info")
    root_info.resizable(width=False, height=False)
    
    label_info = Label(root_info, text='Информация: \n Данная программа создана для управления вашим компьютером.\n В будущем появятся новые обновления!')
    label_info.pack()
    
    button_info = Button(root_info, text= 'Понятно', command=click_info, width= 30, foreground='green')
    button_info.place(x= 100, y = 100)
    
    label_version = Label(root_info, text='Version: 1.0')
    label_version.place(x = 320, y = 170)

def shutdown ():
    os.system("shutdown /s /t 0")

def exp ():
    path_exp = ('C:\Windows\explorer.exe')
    os.startfile(path_exp)

def disp_laptop ():
    path_disp_laptop = ('C:\Windows\System32\devmgmt.msc')
    os.startfile(path_disp_laptop)

def disp ():
    path_disp = ('C:\WINDOWS\system32\Taskmgr.exe')
    os.startfile(path_disp)

def discord ():
    webbrowser.open('https://discord.com/')

def telegram ():
    webbrowser.open('https://web.telegram.org/a/')


def browser ():
    webbrowser.open('https://yandex.ru')

def cmd ():
    path_cmd = 'C:\WINDOWS\system32\cmd.exe'
    os.startfile(path_cmd)

root = Tk()
root.title("Мастер Управления Компьютером")
root.geometry("600x500")
root.resizable(width=False, height=False)
root['background']='blue'

label_hello = Label(root, text="Приветствую вас в Мастере Управления Компьютера !", foreground="black",background='blue')
label_hello.pack()

label_stn = Label(root, text='Standart', foreground='black', background='blue', width= 20, height= 5)
label_stn.place(x= 20, y= 50)

label_pro = Label(root, text='Pro', background='blue', foreground='black', width= 20, height= 5)
label_pro.place(x= 410, y = 50)



button_cmd = Button(root, text="Открыть CMD", foreground="black", command= cmd, width= 25,background='grey')  
button_cmd.place(x= 10, y = 150)

button_yandex = Button(root, text='Открыть Браузер', command=browser, foreground='black', width= 25,background='grey')
button_yandex.place(x= 10, y = 200)

button_telegram = Button(root, text='Открыть веб-браузерный Telegram', command= telegram, foreground='black', width= 30,background='grey')
button_telegram.place(x= 10, y= 250)

button_discord = Button(root, text='Открыть веб-браузерный Discord', command= discord, foreground='black', width= 30,background='grey')
button_discord.place(x= 10, y = 300)

button_disp = Button(root, text='Открыть диспетчер задач', foreground='black', width= 25, command= disp,background='grey')
button_disp.place(x = 10, y = 350)

button_disp_laptop = Button(root, text='Открыть диспетчер устройств', foreground='black', width= 25, command= disp_laptop,background='grey')
button_disp_laptop.place(x = 10, y = 400)

button_exp = Button(root, text='Запуск Explorer.exe', foreground='black', width= 25, command= exp,background='grey')
button_exp.place(x = 400, y = 150)

button_shutdown = Button(root, text= 'Экстренное выключение', foreground='black', width= 25, command= shutdown,background='grey')
button_shutdown.place(x = 400, y = 200)

button_info = Button(root, text='Информация', foreground='black', width= 25, command= info,background='grey')
button_info.place(x = 400, y = 400)

root.mainloop()